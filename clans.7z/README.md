"# clans" 
